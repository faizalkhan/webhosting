<?php include('header.php'); ?>
        <!--Start page-banner-->
        <section class="page-banner" style="background-image:url(images/resources/banner.jpg); background-size: cover;">
            <div class="container">
                <div class="content">
                    <h2>About Us</h2>
                   
                </div>
                <ul class="breadcumb">
                    <li><a href="index">Home</a><i class="fa fa-chevron-right" aria-hidden="true"></i></li>
                    <li><a  class="active" href="javascript:void(0);">About Us</a></li>
                </ul>
            </div>
        </section>
        <!--End page-banner-->
		
<div class="sidebar-page style-2">
			<div class="container">
				<div class="row clearfix">            	
					<!--Content Side-->	
					<div class="col-md-8 col-sm-12 col-xs-12">
						                                             
							<!--Blog Post-->
							<article class="single-blog-post style-two">
								<div class="post-inner">
									
									<div class="comments-area">
							<div class="group-title text-uppercase"><h2 class="mt-o">Leading Software Training Institute in Chennai</h2></div>
							
							
						</div>
									
									<div class="mb-40">
										<div class="text style-two"><p>Tamil Puzhavan is one of the best IT Training institute in Chennai, we are team of dynamic industry professionals educating the workforce entering the IT industry. Our trainers are highly experienced and technical friendly professionals working with top MNCs with hands on experience and depth knowledge in each subject matter. Our training approach is the Best Software Training Institute in Chennai with following features,</p></div>
										
										
									 
									</div>
									<!--<blockquote>Lorem ipsum dolor sit amet, consectetur adipisicing elitsed do eiusmod tempor incididunt ut labore et dolore magna aliqua Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commo do consequat.
										<div class="quate"><i class="fa fa-quote-right" aria-hidden="true"></i></div>
									</blockquote>-->
									
										
										<div class="comments-area">
							<div class="group-title text-uppercase"><h2 class="mt-o fntwt-400">Why Tamil Puzhavan ?</h2></div>
							
							
						</div>
														
						    <div class="mb-40">
										
										<ul class="myls">
  <li>We have got great infrastructure for you to keep practicing on your own time· Unlimited lab / practice environment access provided to all candidates.</li>
  <li>We have got great infrastructure for you to keep practicing on your own time· Unlimited lab / practice environment access provided to all candidates.</li>
  <li>We have got great infrastructure for you to keep practicing on your own time· Unlimited lab / practice environment access provided to all candidates.</li>
  <li>We have got great infrastructure for you to keep practicing on your own time· Unlimited lab / practice environment access provided to all candidates.</li>
  <li>We have got great infrastructure for you to keep practicing on your own time· Unlimited lab / practice environment access provided to all candidates.</li>
  <li>We have got great infrastructure for you to keep practicing on your own time· Unlimited lab / practice environment access provided to all candidates.</li>
</ul>
										
									 
									</div> 


 <div class="mb-40">
										
							<div class="mmags"><h3 class="fde">Join The <span>25,000+</span> Satisfied Candidates Today!</h3>
<a href="contact-us" class="thm-btn inverse">contact us</a> </div> 
									 
									</div>              									
									
									
									<div class="comments-area">
							<div class="group-title text-uppercase"><h2 class="mt-o fntwt-400">TRENDING TRAINING COURSES</h2></div>
							
							
						</div>
														
						    <div class="mb-40">
										
										<div class="row">
										<div class="col-sm-4">
										<div class="features_item">
								<figure class="image_box">
									<img src="images/resources/f1.jpg" alt="">
								</figure>
								<div class="content_box">
									<h3><a href="python-training">Python Training</a></h3>
									<p>Python training in Chennai conducted by Tamil  ...</p>
								</div>
								<span class="border_bottom"></span>
							</div>
										</div>
										
										<div class="col-sm-4">
										<div class="features_item">
								<figure class="image_box">
									<img src="images/resources/f2.jpg" alt="">
								</figure>
								<div class="content_box">
									<h3><a href="aws-training">AWS Training</a></h3>
									<p>Python training in Chennai conducted by Tamil  ...</p>
								</div>
								<span class="border_bottom"></span>
							</div>
										</div>
										
										<div class="col-sm-4">
										<div class="features_item">
								<figure class="image_box">
									<img src="images/resources/f3.jpg" alt="">
								</figure>
								<div class="content_box">
									<h3><a href="python-training">Core JAVA And J2EE </a></h3>
									<p>Python training in Chennai conducted by Tamil  ...</p>
								</div>
								<span class="border_bottom"></span>
							</div>
										</div>
										</div>
										
									 
									</div> 
									
									
									
									  <div class="mb-40">
									  
									  <div class="comments-area">
							<div class="group-title text-uppercase"><h2 class="mt-o">Software Training with Placement in Chennai</h2></div>
							
							
						</div>
										
										<div class="text style-two"><p>Tamil Puzhavan is one of the best IT Training institute in Chennai, we are team of dynamic industry professionals educating the workforce entering the IT industry. Our trainers are highly experienced and technical friendly professionals working with top MNCs with hands on experience and depth knowledge in each subject matter. Our training approach is the Best Software Training Institute in Chennai with following features,</p></div>
										
									 
									</div> 
									
									
								</div>
							</article>
							
					<!--Comments Area-->
						                               
						
					</div>
					<!--Content Side-->
					
					<!--Sidebar-->	
					<?php include('side-manu2.php'); ?>                            
				</div>
			</div>
		</div>


	

<?php include('footer.php'); ?>

