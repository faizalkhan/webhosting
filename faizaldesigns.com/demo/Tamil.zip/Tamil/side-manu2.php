<div class="col-md-4 col-sm-6 col-xs-12">
						<aside class="sidebar"> 
						
						
						<div class="jjhdsd wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
						<div class="sidebar-title">
									<h4 style="    margin-bottom: 20px;">QUICK ENQUIRY</h4>
								</div>
 <form action="mail.php" method="post">
 	<input type="hidden" name="date" value="<?=date('Y-m-d')?>">
    <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
      <input id="email" type="text" class="form-control" name="name" placeholder="Name *" required="">
    </div>
     <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-phone"></i></span>
      <input id="email" type="text" class="form-control" name="mobile" placeholder="Phone No *" required="">
    </div>
	
	 <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
      <input id="email" type="text" class="form-control" name="email" placeholder="Email Address *" required="">
    </div>
	
	<div style="margin-bottom:15px">
	<select class="selectpicker" name="training">
 <option value="Python Training">Python Training</option>
  <option value="AWS Training">AWS Training</option>
  <option value="Core JAVA And J2EE Training">Core JAVA And J2EE Training</option>
 
</select>
</div>
	
	<div class="form-group">
 
  <textarea class="form-control" rows="5" id="comment" name="msg"  placeholder="Enter your text here"></textarea>
</div>
	<button type="submit" class="thm-btn inverse" style="    width: 100%;
    text-align: center;">Send Now</button>
    
  </form>

  
					</div>	
					
					
					<aside class="sidebar wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms" style="    padding-left: 0;
    margin-top: 40px;"> 
  <!-- Popular Categories -->
							<div class="widget popular-categories wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
								<div class="sidebar-title">
								<hr>
									<h3>TRAINING </h3>
									<hr>
								</div>

								<ul class="list">
									<li><a href="python-training"><span class="icon-left fa fa-chevron-right"></span>Python Training</a></li>
									<li><a href="aws-training"><span class="icon-left fa fa-chevron-right"></span>AWS Training</a></li>
									<li><a href="core-java-and-j2ee-training"><span class="icon-left fa fa-chevron-right"></span>Core JAVA And J2EE Training</a></li>
									
								</ul>
							</div>
							</aside> 

<div class="popular_tags wow fadeInUp animated" data-wow-duration="1500ms" style="visibility: visible; animation-name: fadeInUp;">
								<div class="sidebar-title">
								<hr>
									<h3>STUDENT REVIEWS</h3>
									<hr>
								</div>
								
								
								
								<div class="carousel slide" id="fade-quote-carousel" data-ride="carousel" data-interval="3000">
				  <!-- Carousel indicators -->
                  <ol class="carousel-indicators">
				    <li data-target="#fade-quote-carousel" data-slide-to="0" class="active"></li>
				    <li data-target="#fade-quote-carousel" data-slide-to="1"></li>
				    <li data-target="#fade-quote-carousel" data-slide-to="2"></li>
                    <li data-target="#fade-quote-carousel" data-slide-to="3"></li>
                    <li data-target="#fade-quote-carousel" data-slide-to="4"></li>
                    <li data-target="#fade-quote-carousel" data-slide-to="5"></li>
				  </ol>
				  <!-- Carousel items -->
				  <div class="carousel-inner">
				    <div class="item active">
                        <div class="profile-circle"> <img src="images/resources/f4.jpg" style="border-radius: 50%;"/></div>
				    	<blockquote>
				    		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quidem, veritatis nulla eum laudantium totam tempore optio doloremque laboriosam quas, quos eaque molestias odio aut eius animi. Impedit temporibus nisi accusamus. </p>
				    	</blockquote>	
				    </div>
				     <div class="item">
                        <div class="profile-circle"> <img src="images/resources/f4.jpg" style="border-radius: 50%;"/></div>
				    	<blockquote>
				    		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quidem, veritatis nulla eum laudantium totam tempore optio doloremque laboriosam quas, quos eaque molestias odio aut eius animi. Impedit temporibus nisi accusamus.</p>
				    	</blockquote>	
				    </div>
					<div class="item">
                        <div class="profile-circle"> <img src="images/resources/f4.jpg" style="border-radius: 50%;"/></div>
				    	<blockquote>
				    		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quidem, veritatis nulla eum laudantium totam tempore optio doloremque laboriosam quas, quos eaque molestias odio aut eius animi. Impedit temporibus nisi accusamus.</p>
				    	</blockquote>	
				    </div>
					<div class="item">
                        <div class="profile-circle"> <img src="images/resources/f4.jpg" style="border-radius: 50%;"/></div>
				    	<blockquote>
				    		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quidem, veritatis nulla eum laudantium totam tempore optio doloremque laboriosam quas, quos eaque molestias odio aut eius animi. Impedit temporibus nisi accusamus.</p>
				    	</blockquote>	
				    </div>
					<div class="item">
                        <div class="profile-circle"> <img src="images/resources/f4.jpg" style="border-radius: 50%;"/></div>
				    	<blockquote>
				    		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quidem, veritatis nulla eum laudantium totam tempore optio doloremque laboriosam quas, quos eaque molestias odio aut eius animi. Impedit temporibus nisi accusamus.</p>
				    	</blockquote>	
				    </div>
					<div class="item">
                        <div class="profile-circle"> <img src="images/resources/f4.jpg" style="border-radius: 50%;"/></div>
				    	<blockquote>
				    		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quidem, veritatis nulla eum laudantium totam tempore optio doloremque laboriosam quas, quos eaque molestias odio aut eius animi. Impedit temporibus nisi accusamus.</p>
				    	</blockquote>	
				    </div>
				  </div>
				</div>

</div>	

<div>

</div>							
							
						<!--<div class="popular_tags wow fadeInUp animated" data-wow-duration="1500ms" style="visibility: visible; animation-name: fadeInUp;">
								<div class="sidebar-title">
								<hr>
									<h3>OUR REVIEWS ACROSS INTERNET</h3>
									<hr>
								</div>
								
<img src="images/ff.png" style="width: 82px;"/>								
<ul>

<h5 style="margin-bottom: 20px;">5  out of 5  based on 12263 ratings.</h5>
								<table style="width:100%" class="myclstab">

  <tr>
    <td>Google </td>
    <td><img src="images/ff.png" class="rsdd"/></td> 
  </tr>
   <tr>
    <td>Facebook  </td>
    <td><img src="images/ff.png" class="rsdd"/></td> 
  </tr>
  
   <tr>
    <td>UrbanPro  </td>
    <td><img src="images/ff.png" class="rsdd"/></td> 
  </tr>
  
   <tr>
    <td>Sulekha </td>
    <td><img src="images/ff.png" class="rsdd"/></td> 
  </tr>
  
   <tr>
    <td>Yet5  </td>
    <td><img src="images/ff.png" class="rsdd"/></td> 
  </tr>
   <tr>
    <td>Justdial  </td>
    <td><img src="images/ff.png" class="rsdd"/></td> 
  </tr>

</table>
</ul>
							</div> 
							
							
					
							
							<div class="popular_tags wow fadeInUp animated" data-wow-duration="1500ms" style="visibility: visible; animation-name: fadeInUp;">
								<div class="sidebar-title">
								<hr>
									<h3>TAGS</h3>
									<hr>
								</div>

								<ul>
									<li><a href="#" class="tran3s">Automation testing</a></li>
									<li><a href="#" class="tran3s">Automation </a></li>
									<li><a href="#" class="tran3s"> testing</a></li>
									<li><a href="#" class="tran3s">Automation testing</a></li>
									<li><a href="#" class="tran3s">Automation </a></li>
									<li><a href="#" class="tran3s"> testing</a></li><li><a href="#" class="tran3s">Automation testing</a></li>
									<li><a href="#" class="tran3s">Automation </a></li>
									<li><a href="#" class="tran3s"> testing</a></li>
									
								</ul>
							</div> -->
						</aside>                                  
					</div>
					<!--Sidebar-->   