
					<!--Sidebar-->	
					<div class="col-md-4 col-sm-6 col-xs-12">
						<aside class="sidebar"> 
							
							

							<div class="recent-news wow fadeInUp" data-wow-duration="1200ms" style="visibility: visible; animation-name: fadeInUp;">
								<div class="sidebar-title">
									<h3>Recent News</h3>
								</div>	
                                        
                                <div class="single-news">
                                    <figure class="image-holder">
                                        <a href="blog-in"><img src="images/blog/1.jpg" alt="Images" style="height: 43px;"></a>
                                    </figure>

                                    <div class="text">
                                        <h4><a href="blog-in">Blog Post Blog Post</a>
                                        </h4>
                                        <p><i class="fa fa-calendar-check-o" aria-hidden="true"></i> 20 / 07 / 201</p>
                                    </div>
                                </div>
								        
                                <div class="single-news">
                                    <figure class="image-holder">
                                        <a href="blog-in"><img src="images/blog/1.jpg" alt="Images" style="height: 43px;"></a>
                                    </figure>

                                    <div class="text">
                                        <h4><a href="blog-in">Blog Post Blog Post</a>
                                        </h4>
                                        <p><i class="fa fa-calendar-check-o" aria-hidden="true"></i> 20 / 07 / 201</p>
                                    </div>
                                </div>
								
								        
                                <div class="single-news">
                                    <figure class="image-holder">
                                        <a href="blog-in"><img src="images/blog/1.jpg" alt="Images" style="height: 43px;"></a>
                                    </figure>

                                    <div class="text">
                                        <h4><a href="blog-in">Blog Post Blog Post</a>
                                        </h4>
                                        <p><i class="fa fa-calendar-check-o" aria-hidden="true"></i> 20 / 07 / 201</p>
                                    </div>
                                </div>
								
								        
                                <div class="single-news">
                                    <figure class="image-holder">
                                        <a href="blog-in"><img src="images/blog/1.jpg" alt="Images" style="height: 43px;"></a>
                                    </figure>

                                    <div class="text">
                                        <h4><a href="blog-in">Blog Post Blog Post</a>
                                        </h4>
                                        <p><i class="fa fa-calendar-check-o" aria-hidden="true"></i> 20 / 07 / 201</p>
                                    </div>
                                </div>
								
								
                               
                            </div>
							
							
							
						</aside>                                   
					</div>
					<!--Sidebar-->