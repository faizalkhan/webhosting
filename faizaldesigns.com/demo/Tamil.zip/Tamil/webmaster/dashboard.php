<?php include('head.php');?>
            <!-- Top Bar End -->


            <!-- Page content start -->
            <div class="page-contentbar">

                <!--left navigation start-->
               <?php include('menu.php');?>
                <!--left navigation end-->

                <!-- START PAGE CONTENT -->
                <div id="page-right-content">

                    <div class="container">
                        <div class="row">
							<h3>Tamil Puzhavan administrator</h3>
						</div>
                        <!--end row -->


                    </div>
                    <!-- end container -->

                    <div class="footer">
                       
                        <div>
                            <strong>Tamil Puzhavan</strong> - Copyright &copy; 2018
                        </div>
                    </div> <!-- end footer -->

                </div>
                <!-- End #page-right-content -->

            </div>
            <!-- end .page-contentbar -->
        </div>
        <!-- End #page-wrapper -->



       <?php include('tail.php');?>