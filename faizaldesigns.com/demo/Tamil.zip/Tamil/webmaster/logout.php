<?php
ob_start();

session_start();

session_destroy();

header("Location:index.php");

session_start();

$_SESSION['msg']="You are Successfully logout..!";

?>