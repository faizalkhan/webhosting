<?php include('header.php'); ?>
        <!--Start page-banner-->
        <section class="page-banner" style="background-image:url(images/resources/banner.jpg); background-size: cover;">
            <div class="container">
                <div class="content">
                    <h2>.Net Training</h2>
                   
                </div>
                <ul class="breadcumb">
                    <li><a href="index">Home</a><i class="fa fa-chevron-right" aria-hidden="true"></i></li> 
					<li><a href="javascript:void(0);">Training</a><i class="fa fa-chevron-right" aria-hidden="true"></i></li>
                    <li><a  class="active" href="javascript:void(0);">.Net Training</a></li>
                </ul>
            </div>
        </section>
        <!--End page-banner-->
		
<div class="sidebar-page style-2">
			<div class="container">
				<div class="row clearfix">            	
					<!--Content Side-->	
					<div class="col-md-8 col-sm-12 col-xs-12">
						                                             
							<!--Blog Post-->
							<article class="single-blog-post style-two">
								<div class="post-inner">
									
									<div class="comments-area">
							<div class="group-title text-uppercase"><h2 class="mt-o">.Net Training</h2></div>
							
							
						</div>
						
						
						<div class="feature-style-three" style="padding: 0;">
            <div class="">         
                <div class="item-list" style="border-bottom: 0px solid #ededed;">
                    <div class="row">
					       <div class="item">
                            <div class="column col-md-3">
                                <div class="inner-box">
                                    <div class="icon-box"><span class="icon fa fa-book"></span></div>
                                    <h3>
Course Content</h3>
                                    
                                </div>
                            </div>
                        </div>
                        
                        <div class="item">
                           <div class="column col-md-3">
                                <div class="inner-box">
                                    <div class="icon-box"><span class="icon fa fa-question"></span></div>
                                    <h3>FAQ’s</h3>
                                   
                                </div>
                            </div>
                        </div>
						
						 <div class="item">
                            <div class="column col-md-3">
                                <div class="inner-box">
                                    <div class="icon-box"><span class="icon fa fa-pencil-square-o"></span></div>
                                    <h3>Reviews</h3>
                                   
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="column col-md-3">
                                <div class="inner-box">
                                    <div class="icon-box"><span class="icon fa fa-phone"></span></div>
                                    <h3>Call us</h3>
                                   
                                </div>
                            </div>
                        </div>
                        
                 
                    </div>
                </div>
            </div>
        </div>
						
									
									<div class="mb-40">
										<div class="text style-two"><p>CREDO SYSTEMZ is one of the best IT Training institute in Chennai, we are team of dynamic industry professionals educating the workforce entering the IT industry. Our trainers are highly experienced and technical friendly professionals working with top MNCs with hands on experience and depth knowledge in each subject matter. Our training approach is the Best Software Training Institute in Chennai with following features,</p></div>
										
										
									 
									</div>
									<!--<blockquote>Lorem ipsum dolor sit amet, consectetur adipisicing elitsed do eiusmod tempor incididunt ut labore et dolore magna aliqua Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commo do consequat.
										<div class="quate"><i class="fa fa-quote-right" aria-hidden="true"></i></div>
									</blockquote>-->
									
										
										<div class="comments-area">
							<div class="group-title text-uppercase"><h2 class="mt-o fntwt-400">Why CREDO SYSTEMZ ?</h2></div>
							
							
						</div>
														
						    <div class="mb-40">
										
										<ul class="myls">
  <li>We have got great infrastructure for you to keep practicing on your own time· Unlimited lab / practice environment access provided to all candidates.</li>
  <li>We have got great infrastructure for you to keep practicing on your own time· Unlimited lab / practice environment access provided to all candidates.</li>
  <li>We have got great infrastructure for you to keep practicing on your own time· Unlimited lab / practice environment access provided to all candidates.</li>
  <li>We have got great infrastructure for you to keep practicing on your own time· Unlimited lab / practice environment access provided to all candidates.</li>
  <li>We have got great infrastructure for you to keep practicing on your own time· Unlimited lab / practice environment access provided to all candidates.</li>
  <li>We have got great infrastructure for you to keep practicing on your own time· Unlimited lab / practice environment access provided to all candidates.</li>
</ul>
										
									 
									</div> 
									
									
									
										
										<div class="comments-area">
							<div class="group-title text-uppercase"><h2 class="mt-o fntwt-400">Why CREDO SYSTEMZ ?</h2></div>
							
							
						</div>
														
						    <div class="mb-40">
									<div>	
									<div class="gdsffd">FAQ’s</div>
									<div class="dfhsyuds"><p class="dfudshd">We have got great infrastructure for you to keep practicing on your own time· Unlimited lab / practice environment access provided to all candidates.</p></div>
									 
									</div> 
									</div>
									
									
									 <div class="mb-40">
									<div>	
									<div class="gdsffd">FAQ’s</div>
									<div class="dfhsyuds"><p class="dfudshd">We have got great infrastructure for you to keep practicing on your own time· Unlimited lab / practice environment access provided to all candidates.</p></div>
									 
									</div> 
									</div>
									
									 <div class="mb-40">
									<div>	
									<div class="gdsffd">FAQ’s</div>
									<div class="dfhsyuds"><p class="dfudshd">We have got great infrastructure for you to keep practicing on your own time· Unlimited lab / practice environment access provided to all candidates.</p></div>
									 
									</div> 
									</div>
									
									
									
									
									<div class="comments-area">
							<div class="group-title text-uppercase"><h2 class="mt-o fntwt-400">Queries You may have</h2></div>
							
							
						</div>
														
						    <div class="mb-40">
									<div>	
									<div class="gdsffd">YES!</div>
									<div class="dfhsyuds"><p class="dfudshd">AngularJS is written in JavaScript and when you are writing code for AngularJS You will be writing JavaScript. So it’s essential to know JavaScript before learning AngularJs.</p></div>
									 
									</div> 
									</div>
									
									
									 <div class="mb-40">
									<div>	
									<div class="gdsffd">FAQ’s</div>
									<div class="dfhsyuds"><p class="dfudshd">We have got great infrastructure for you to keep practicing on your own time· Unlimited lab / practice environment access provided to all candidates.</p></div>
									 
									</div> 
									</div>
									
									 <div class="mb-40">
									<div>	
									<div class="gdsffd">FAQ’s</div>
									<div class="dfhsyuds"><p class="dfudshd">We have got great infrastructure for you to keep practicing on your own time· Unlimited lab / practice environment access provided to all candidates.</p></div>
									 
									</div> 
									</div>
									
									
									
									
									<div class="comments-area">
							<div class="group-title text-uppercase"><h2 class="mt-o fntwt-400">Queries You may have</h2></div>
							
							
						</div>
														
						    <div class="mb-40">
									
<div class=" content">
   <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">

      <div class="carousel-inner">
         <div class="item active">
            <div class="row">
               <div class="col-xs-12">
                  <div class=" adjust1">
                   
                     <div class="col-xs-12">
                        <div class="caption" style="    text-align: center;">
						<h1><span class="fa fa-quote-left" style="    color: #3498db;
    padding-bottom: 20px;"></span></h1>
                           <h4>Name</h4>
                           <p style="    padding: 10px 100px">We have got great infrastructure for you to keep practicing on your own time· Unlimited lab / practice environment access provided to all candidates.</p>
                           
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
		 
		 <div class="item">
            <div class="row">
               <div class="col-xs-12">
                  <div class=" adjust1">
                   
                     <div class="col-xs-12">
                        <div class="caption" style="    text-align: center;">
						<h1><span class="fa fa-quote-left" style="    color: #3498db;
    padding-bottom: 20px;"></span></h1>
                           <h4>Name</h4>
                           <p style="    padding: 10px 100px">We have got great infrastructure for you to keep practicing on your own time· Unlimited lab / practice environment access provided to all candidates.</p>
                           
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
       
      </div>
      <!-- Controls --> <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev"> <span class="glyphicon glyphicon-chevron-left"></span> </a> <a class="right carousel-control" href="#carousel-example-generic" data-slide="next"> <span class="glyphicon glyphicon-chevron-right"></span> </a> 
   </div>
</div>
									
									
									</div>
									
									
									
									
									

       									
									
								
														
							
									
								</div>
							</article>
							
					<!--Comments Area-->
						                               
						
					</div>
					<!--Content Side-->
					
				<?php include('side-manu2.php'); ?>                         
				</div>
			</div>
		</div>


	

<?php include('footer.php'); ?>

